from setuptools import setup

setup(
    name="CustomPredict",
    version="0.5",
    scripts=["custom_predict.py"],
)